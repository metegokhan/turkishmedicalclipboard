import json

# ATC indeksini barkod-ATC eşleşmesine çeviren program
def convert_atc_to_barcode_mapping():
    try:
        # ATC indeks dosyasını oku
        with open('atc_index.json', 'r', encoding='utf-8') as file:
            atc_to_barcodes = json.load(file)
        
        # Ters indeks oluştur (barkod -> ATC)
        barcode_to_atc = {}
        
        for atc, barcodes in atc_to_barcodes.items():
            for barcode in barcodes:
                barcode_to_atc[str(barcode)] = atc
        
        # Sonucu yeni JSON dosyasına kaydet
        with open('barcod-atc.json', 'w', encoding='utf-8') as file:
            json.dump(barcode_to_atc, file, indent=2, ensure_ascii=False)
        
        print(f"Dönüşüm başarılı!")
        print(f"Toplam {len(barcode_to_atc)} barkod işlendi.")
        
        # Örnek test
        print("\nÖrnek sorgular:")
        test_barcodes = ['8699569900061', '8681308961235', '8699591150397']
        for barcode in test_barcodes:
            if barcode in barcode_to_atc:
                print(f"Barkod {barcode}: ATC {barcode_to_atc[barcode]}")
            else:
                print(f"Barkod {barcode}: Bulunamadı")
                
    except FileNotFoundError:
        print("Hata: atc_index.json dosyası bulunamadı!")
    except json.JSONDecodeError:
        print("Hata: atc_index.json dosyası geçerli bir JSON formatında değil!")
    except Exception as e:
        print(f"Hata oluştu: {e}")

# Programı çalıştır
if __name__ == "__main__":
    convert_atc_to_barcode_mapping()
